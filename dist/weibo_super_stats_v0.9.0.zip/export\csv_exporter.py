from __future__ import annotations

import csv
from collections.abc import Iterable
from pathlib import Path
from typing import Any

DEFAULT_EXPORT_COLUMN_MAP = [
    ("user_name", "作者昵称"),
    ("publish_time", "帖子发送时间"),
    ("post_url", "帖子链接"),
    ("original_image_urls", "原图链接"),
    ("image_local_paths", "图片本地路径"),
    ("content", "帖子内容"),
    ("reposts", "转发数"),
    ("comments", "评论总数"),
    ("likes", "点赞数"),
    ("non_author_comments", "非楼主评论数"),
    ("author_replies", "楼主回复数"),
    ("topic_comment_factor", "话题评论系数"),
    ("score", "帖子分数"),
    ("engagement_total", "互动总量"),
    ("top_comment_1", "热评1(按点赞)"),
    ("top_comment_2", "热评2(按点赞)"),
    ("top_comment_3", "热评3(按点赞)"),
]


def export_posts_csv(
    posts: Iterable[dict[str, Any]],
    csv_path: Path,
    column_map: list[tuple[str, str]] | None = None,
) -> None:
    column_map = column_map or DEFAULT_EXPORT_COLUMN_MAP
    csv_path.parent.mkdir(parents=True, exist_ok=True)
    headers = [cn for _, cn in column_map]
    with csv_path.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=headers)
        writer.writeheader()
        for post in posts:
            writer.writerow(build_export_row(post, column_map))


def build_export_row(post: dict[str, Any], column_map: list[tuple[str, str]]) -> dict[str, Any]:
    return {cn: post.get(en, "") for en, cn in column_map}
